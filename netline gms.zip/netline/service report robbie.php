<?php
require('fpdf.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Field Site Service Report</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
        font-size: 12px;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        position: relative;
        page-break-inside: avoid;
    }
    .header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 20px;
    }
    .header img {
        max-width: 100%;
        max-height: 120px;
        display: block;
    }
    .contact-info {
        text-align: right;
        max-width: 60%;
        color: blue;
    }
    .contact-info p {
        margin: 0;
        font-size: 12px;
        line-height: 1.5;
    }
    h2 {
        margin-top: 0;
        text-align: center;
        color: #333;
    }
    form {
        margin-bottom: 10px;
        column-count: 2;
        column-gap: 10px;
    }
    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #333;
        font-size: 12px;
    }
    input[type="text"], input[type="date"], textarea, select {
        width: calc(70% - 18px);
        padding: 5px;
        margin-bottom: 7px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
        font-size: 12px;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    .signature-pad {
        border: 1px solid #ccc;
        padding: 3px;
        width: 100%;
        height: 150px;
        margin-bottom: 5px;
    }
    .parts-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 5px;
    }
    .parts-table th, .parts-table td {
        border: 1px solid #ccc;
        padding: 6px;
        text-align: left;
        font-size: 12px;
    }
</style>
</head>
<body>

<div class="container">
    <div class="header">
        <img src="img/logo.png" alt="Company Logo">
        <div class="contact-info">
            <p>Kirichwa Lane Court, Suite 28, Off Ngong Road</p>
            <p>P.O. Box 106256-00100 Nairobi</p> 
            <p>Tel: +254 20 440 290/ Cell: +254 782 263 444</p>
            <p>Email: info@netline.co.ke</p> 
            <p>Website: www.netline.co.ke</p>
        </div>
    </div>
    
    <h2>Field Site Service Report</h2>

    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "netline";
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $client_details = [];
    $sql = "SELECT company_name, site, technician_contact, technician_email FROM client WHERE id = ?";
    $client_id = 1;
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $client_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $client_details = $result->fetch_assoc();
    } else {
        echo "No client details found.";
        exit();
    }
    $stmt->close();

    $job_number = "JOB-" . strtoupper(uniqid());
    ?>

    <form action="submit_report.php" method="post">
        <input type="hidden" name="client_id" value="<?php echo $client_id; ?>">
        <input type="hidden" name="job_number" value="<?php echo $job_number; ?>">

        <label for="company_name">Company Name:</label>
        <input type="text" name="company_name" id="company_name" value="<?php echo $client_details['company_name']; ?>" readonly>

        <label for="site">Site:</label>
        <input type="text" name="site" id="site" value="<?php echo $client_details['site']; ?>" readonly>

        <label for="engine_model">Engine Model:</label>
        <select name="engine_model" id="engine_model" required>
            <option value="">Select Engine Model</option>
            <?php
            $sql = "SELECT EngineModelNumber FROM engineinformation";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo '<option value="' . $row['EngineModelNumber'] . '">' . $row['EngineModelNumber'] . '</option>';
                }
            } else {
                echo '<option value="">No engine models found</option>';
            }
            ?>
        </select>

        <label for="serial_number">Serial Number:</label>
        <input type="text" name="serial_number" id="serial_number" required>

        <label for="running_hours">Running Hours:</label>
        <input type="text" name="running_hours" id="running_hours" required>

        <label for="service_intervals">Service Intervals:</label>
        <input type="text" name="service_intervals" id="service_intervals" required>

        <label for="service_type">Service Type:</label>
        <select name="service_type" id="service_type" required>
            <option value="">Select Service Type</option>
            <option value="Oil Change">Oil Change</option>
            <option value="Filter Replacement">Filter Replacement</option>
            <option value="General Maintenance">General Maintenance</option>
        </select>

        <label for="engine_checks">Engine Checks:</label><br>
        <input type="radio" name="engine_checks" id="engine_checks_yes" value="Yes">
        <label for="engine_checks_yes">Yes</label>
        <input type="radio" name="engine_checks" id="engine_checks_no" value="No">
        <label for="engine_checks_no">No</label><br>

        <label for="diagnosis">Diagnosis:</label>
        <textarea name="diagnosis" id="diagnosis" rows="3" required></textarea>

        <label for="root_cause">Root Cause:</label>
        <textarea name="root_cause" id="root_cause" rows="3" required></textarea>

        <label for="actions_taken">Actions Taken:</label>
        <textarea name="actions_taken" id="actions_taken" rows="3" required></textarea>

        <label for="comments">Comments:</label>
        <textarea name="comments" id="comments" rows="3"></textarea>

        <label for="client_signature">Client Signature:</label>
        <div class="signature-pad" id="client_signature_pad">
            <canvas id="client_signature_canvas" width="400" height="150"></canvas>
        </div>
        <input type="hidden" name="client_signature" id="client_signature">

        <label for="technician_signature">Technician Signature:</label>
        <div class="signature-pad" id="technician_signature_pad">
            <canvas id="technician_signature_canvas" width="400" height="150"></canvas>
        </div>
        <input type="hidden" name="technician_signature" id="technician_signature">

        <input type="submit" name="submit" value="Submit Report">
    </form>
</div>

<script>
    // Client signature handling
    var clientCanvas = document.getElementById('client_signature_canvas');
    var clientCtx = clientCanvas.getContext('2d');
    var clientIsDrawing = false;
    var clientLastX = 0;
    var clientLastY = 0;

    clientCanvas.addEventListener('mousedown', function(e) {
        clientIsDrawing = true;
        [clientLastX, clientLastY] = [e.offsetX, e.offsetY];
    });

    clientCanvas.addEventListener('mousemove', function(e) {
        if (clientIsDrawing) {
            clientDrawLine(clientLastX, clientLastY, e.offsetX, e.offsetY);
            [clientLastX, clientLastY] = [e.offsetX, e.offsetY];
        }
    });

    clientCanvas.addEventListener('mouseup', function() {
        clientIsDrawing = false;
        saveClientSignature();
    });

    clientCanvas.addEventListener('mouseleave', function() {
        clientIsDrawing = false;
    });

    function clientDrawLine(x1, y1, x2, y2) {
        clientCtx.beginPath();
        clientCtx.moveTo(x1, y1);
        clientCtx.lineTo(x2, y2);
        clientCtx.strokeStyle = '#000';
        clientCtx.lineWidth = 2;
        clientCtx.stroke();
        clientCtx.closePath();
    }

    function saveClientSignature() {
        var clientSignatureData = clientCanvas.toDataURL();
        document.getElementById('client_signature').value = clientSignatureData;
    }

    function clearClientSignature() {
        clientCtx.clearRect(0, 0, clientCanvas.width, clientCanvas.height);
        document.getElementById('client_signature').value = '';
    }

    // Technician signature handling
    var techCanvas = document.getElementById('technician_signature_canvas');
    var techCtx = techCanvas.getContext('2d');
    var techIsDrawing = false;
    var techLastX = 0;
    var techLastY = 0;

    techCanvas.addEventListener('mousedown', function(e) {
        techIsDrawing = true;
        [techLastX, techLastY] = [e.offsetX, e.offsetY];
    });

    techCanvas.addEventListener('mousemove', function(e) {
        if (techIsDrawing) {
            techDrawLine(techLastX, techLastY, e.offsetX, e.offsetY);
            [techLastX, techLastY] = [e.offsetX, e.offsetY];
        }
    });

    techCanvas.addEventListener('mouseup', function() {
        techIsDrawing = false;
        saveTechSignature();
    });

    techCanvas.addEventListener('mouseleave', function() {
        techIsDrawing = false;
    });

    function techDrawLine(x1, y1, x2, y2) {
        techCtx.beginPath();
        techCtx.moveTo(x1, y1);
        techCtx.lineTo(x2, y2);
        techCtx.strokeStyle = '#000';
        techCtx.lineWidth = 2;
        techCtx.stroke();
        techCtx.closePath();
    }

    function saveTechSignature() {
        var techSignatureData = techCanvas.toDataURL();
        document.getElementById('technician_signature').value = techSignatureData;
    }

    function clearTechSignature() {
        techCtx.clearRect(0, 0, techCanvas.width, techCanvas.height);
        document.getElementById('technician_signature').value = '';
    }
</script>

</body>
</html>
