<?php
//require_once('fpdf.php');

// Assuming you have already connected to your database and fetched necessary data
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "netline";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$client_details = [];
$sql = "SELECT company_name, site FROM client WHERE id = ?";
$client_id = 1; // Assuming client ID 1 for demonstration
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $client_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $client_details = $result->fetch_assoc();
} else {
    echo "No client details found.";
    exit();
}
$stmt->close();

$job_number = "JOB-" . strtoupper(uniqid()); // Generate unique job number
$date_time = date('Y-m-d H:i:s'); // Current date and time
?>

<?php
require('fpdf.php');

// Assuming you have already connected to your database and fetched necessary data
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "netline";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$client_details = [];
$sql = "SELECT company_name, site FROM client WHERE id = ?";
$client_id = 1; // Assuming client ID 1 for demonstration
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $client_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $client_details = $result->fetch_assoc();
} else {
    echo "No client details found.";
    exit();
}
$stmt->close();

$job_number = "JOB-" . strtoupper(uniqid()); // Generate unique job number
$date_time = date('Y-m-d H:i:s'); // Current date and time
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FIELD SITE SERVICE REPORT</title>
    <style>
            body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 1000px;
        margin: 0 auto;
        padding: 10px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    .column {
        display: flex;
        flex-direction: column;
        width: 100%;
    }
    .task-table {
        width: 200%;
        border-collapse: collapse;
        margin-top: 10px;
    }
    .task-table, th, td {
        border: 1px solid #ccc;
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    input[type="checkbox"] {
        margin: 0;
        padding: 0;
    }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            font-size: 12px;
        }
        .column {
    width: calc(48% - 10px); /* Adjusted to include gap */
    display: inline-block; /* Ensure columns stay inline */
    vertical-align: top; /* Align columns to the top */
    margin-bottom: 20px; /* Add some bottom margin */
}
.column:first-child {
    margin-right: 10px;
}

/* Ensure radio buttons and labels are displayed inline */
.column div {
    margin-bottom: 10px; /* Add spacing between groups */
}

.column div label {
    display: inline-block; /* Ensure labels behave inline */
    margin-right: 10px; /* Add space between labels and inputs */
}

.column div input[type="radio"] {
    display: inline-block; /* Ensure radio buttons are inline */
    margin-right: 5px; /* Add space between radio buttons and labels */
}

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative;
            page-break-inside: avoid;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .header img {
            max-width: 100%;
            max-height: 120px;
            display: block;
        }
        .contact-info {
            text-align: right;
            max-width: 60%;
            color: blue;
        }
        .contact-info p {
            margin: 0;
            font-size: 12px;
            line-height: 1.5;
        }
        h2 {
            margin-top: 0;
            text-align: center;
            color: #333;
        }
        form {
            margin-bottom: 10px;
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
        }
        .column {
            width: calc(48% - 10px); /* Adjusted to include gap */
        }
        .column:first-child {
            margin-right: 10px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
            font-size: 12px;
        }
        input[type="text"], input[type="date"], textarea, select {
            width: 100%;
            padding: 5px;
            margin-bottom: 7px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 12px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .task-table {
            width: 220%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .task-table th, .task-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }
        .task-table {
            width: 100%; /* Adjusted to take full width of the column */
            max-width: 100%;
            overflow-x: auto; /* Enable horizontal scrolling if needed */
            border-collapse: collapse;
            margin-top: 20px;
        }
        .task-table th, .task-table td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: center;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="header">
        <img src="img/logo.png" alt="Company Logo">
        <div class="contact-info">
            <p>Kirichwa Lane Court, Suite 28, Off Ngong Road</p>
            <p>P.O. Box 106256-00100 Nairobi</p>
            <p>Tel: +254 20 440 290/ Cell: +254 782 263 444</p>
            <p>Email: info@netline.co.ke</p>
            <p>Website: www.netline.co.ke</p>
        </div>
    </div>
    
    <h2>Field Site Service Report</h2>

    <form action="submit_report.php" method="post">
        <input type="hidden" name="client_id" value="<?php echo $client_id; ?>">
        <input type="hidden" name="job_number" value="<?php echo $job_number; ?>">
        <input type="hidden" name="date_time" value="<?php echo $date_time; ?>">

        <div class="column">
            <label for="company_name">Client Name:</label>
            <input type="text" name="company_name" id="company_name" value="<?php echo $client_details['company_name']; ?>" readonly>

            <label for="site">Site:</label>
            <input type="text" name="site" id="site" value="<?php echo $client_details['site']; ?>" readonly>

            <label for="engine_model">Engine Model:</label>
            <select name="engine_model" id="engine_model" required>
                <option value="">Select Engine Model</option>
                <?php
                $sql = "SELECT EngineModelNumber FROM engineinformation";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo '<option value="' . $row['EngineModelNumber'] . '">' . $row['EngineModelNumber'] . '</option>';
                    }
                } else {
                    echo '<option value="">No engine models found</option>';
                }
                ?>
            </select>

            <label for="serial_number">Serial Number:</label>
            <input type="text" name="serial_number" id="serial_number" required>

            <!-- Health and safety risk assessment question -->
            <label>Have you conducted health and safety risk assessment?</label>
            <input type="checkbox" id="risk_assessment_yes" name="risk_assessment" value="yes">
            <label for="risk_assessment_yes">Yes</label>
            <input type="checkbox" id="risk_assessment_no" name="risk_assessment" value="no">
            <label for="risk_assessment_no">No</label>

            <!-- Services requested dropdown -->
            <label for="services_requested">Services Requested:</label>
            <select name="services_requested" id="services_requested" required>
                <option value="">Select Service</option>
                <option value="Routine Maintenance">Routine Maintenance</option>
                <option value="Inspection/Breakdown">Inspection/Breakdown</option>
                <option value="Commissioning">Commissioning</option>
            </select>

            <!-- Last-minute risk assessment question -->
            <label for="diagnosis">Diagnosis:</label>
        <textarea name="diagnosis" id="diagnosis" rows="3" required></textarea>
       

<!-- Task Table -->
<div class="container">
    <div class="column">
        <table class="task-table">
            <thead>
                <tr>
                    <th>Task</th>
                    <th>Done?</th>
                    <th>Task</th>
                    <th>Done?</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>Clean Machine</td>
                    <td><input type="checkbox" id="clean_machine_done" name="clean_machine_done" value="yes"></td>
                    <td>Clean Fluid Level</td>
                    <td><input type="checkbox" id="clean_fluid_level_done" name="clean_fluid_level_done" value="yes"></td>
                </tr>
                <tr>
                    <td>Check Electrical</td>
                    <td><input type="checkbox" id="check_electrical_done" name="check_electrical_done" value="yes"></td>
                    <td>Check Hoses</td>
                    <td><input type="checkbox" id="check_hoses_done" name="check_hoses_done" value="yes"></td>
                </tr>
                <tr>
                    <td>Leakages & Loose connections</td>
                    <td><input type="checkbox" id="leakages_loose_connections_done" name="leakages_loose_connections_done" value="yes"></td>
                    <td>Controller History</td>
                    <td><input type="checkbox" id="controller_history_done" name="controller_history_done" value="yes"></td>
                </tr>
                <tr>
                    <td>Radiator cap</td>
                    <td><input type="checkbox" id="radiator_cap_done" name="radiator_cap_done" value="yes"></td>
                    <td>Fuel Leakage</td>
                    <td><input type="checkbox" id="fuel_leakage_done" name="fuel_leakage_done" value="yes"></td>
                </tr>
                <tr>
                    <td>Radiator Leakage</td>
                    <td><input type="checkbox" id="radiator_leakage_done" name="radiator_leakage_done" value="yes"></td>
                    <td>Fuel cap</td>
                    <td><input type="checkbox" id="fuel_cap_done" name="fuel_cap_done" value="yes"></td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

  

 </div>
<!-- Task Table -->
<div class="column">
    <table class="task-table">
        <thead>
            <tr>
                <th>Parts Name</th>
                <th>Quantity</th>
                <th>Part Number</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Oil Filters</td>
                <td><input type="number" name="oil_filters_quantity" id="oil_filters_quantity" min="0" value="0"></td>
                <td><input type="text" name="oil_filters_part_number" id="oil_filters_part_number"></td>
            </tr>
            <tr>
                <td>Fuel Filters</td>
                <td><input type="number" name="fuel_filters_quantity" id="fuel_filters_quantity" min="0" value="0"></td>
                <td><input type="text" name="fuel_filters_part_number" id="fuel_filters_part_number"></td>
            </tr>
            <tr>
                <td>Air Filters</td>
                <td><input type="number" name="air_filters_quantity" id="air_filters_quantity" min="0" value="0"></td>
                <td><input type="text" name="air_filters_part_number" id="air_filters_part_number"></td>
            </tr>
            <tr>
                <td>Water Filters</td>
                <td><input type="number" name="water_filters_quantity" id="water_filters_quantity" min="0" value="0"></td>
                <td><input type="text" name="water_filters_part_number" id="water_filters_part_number"></td>
            </tr>
            <tr>
                <td>Spark Plugs</td>
                <td><input type="number" name="spark_plugs_quantity" id="spark_plugs_quantity" min="0" value="0"></td>
                <td><input type="text" name="spark_plugs_part_number" id="spark_plugs_part_number"></td>
            </tr>
            <tr>
                <td>Battery</td>
                <td><input type="number" name="battery_quantity" id="battery_quantity" min="0" value="0"></td>
                <td><input type="text" name="battery_part_number" id="battery_part_number"></td>
            </tr>
        </tbody>
    </table>
   <!-- Existing Job Completion Report section -->
<!-- Existing Job Completion Report section -->

    <h3>Job Completion Report</h3>

    <div>
        <label for="job_successful">Was the job successful?</label>
        <input type="radio" id="job_successful_yes" name="job_successful" value="yes">
        <label for="job_successful_yes">Yes</label>
        <input type="radio" id="job_successful_no" name="job_successful" value="no">
        <label for="job_successful_no">No</label>
    </div>

    <div>
        <label for="environment_clean">Have you left the environment clean?</label>
        <input type="radio" id="environment_clean_yes" name="environment_clean" value="yes">
        <label for="environment_clean_yes">Yes</label>
        <input type="radio" id="environment_clean_no" name="environment_clean" value="no">
        <label for="environment_clean_no">No</label>
    </div>

    <div>
        <label>Responsibility for used parts and oil disposal:</label>
        <input type="radio" id="responsibility_customer" name="responsibility_parts" value="customer">
        <label for="responsibility_customer">Customer</label>

        <input type="radio" id="responsibility_netline" name="responsibility_parts" value="netline">
        <label for="responsibility_netline">Netline</label>
    </div>
    <h3>Signatures</h3>
    <label for="client_signature">Client Signature:</label>
        <div class="signature-pad" id="client_signature_pad">
            <canvas id="client_signature_canvas" width="400" height="40"></canvas>
        </div>
        <input type="hidden" name="client_signature" id="client_signature">

        <label for="technician_signature">Technician Signature:</label>
        <div class="signature-pad" id="technician_signature_pad">
            <canvas id="technician_signature_canvas" width="400" height="40"></canvas>
        </div>
        <input type="hidden" name="technician_signature" id="technician_signature">

        <input type="submit" name="submit" value="Submit Report">
    </form>
</div>

<script>
    // Client signature handling
    var clientCanvas = document.getElementById('client_signature_canvas');
    var clientCtx = clientCanvas.getContext('2d');
    var clientIsDrawing = false;
    var clientLastX = 0;
    var clientLastY = 0;

    clientCanvas.addEventListener('mousedown', function(e) {
        clientIsDrawing = true;
        [clientLastX, clientLastY] = [e.offsetX, e.offsetY];
    });

    clientCanvas.addEventListener('mousemove', function(e) {
        if (clientIsDrawing) {
            clientDrawLine(clientLastX, clientLastY, e.offsetX, e.offsetY);
            [clientLastX, clientLastY] = [e.offsetX, e.offsetY];
        }
    });

    clientCanvas.addEventListener('mouseup', function() {
        clientIsDrawing = false;
        saveClientSignature();
    });

    clientCanvas.addEventListener('mouseleave', function() {
        clientIsDrawing = false;
    });

    function clientDrawLine(x1, y1, x2, y2) {
        clientCtx.beginPath();
        clientCtx.moveTo(x1, y1);
        clientCtx.lineTo(x2, y2);
        clientCtx.strokeStyle = '#000';
        clientCtx.lineWidth = 2;
        clientCtx.stroke();
        clientCtx.closePath();
    }

    function saveClientSignature() {
        var clientSignatureData = clientCanvas.toDataURL();
        document.getElementById('client_signature').value = clientSignatureData;
    }

    function clearClientSignature() {
        clientCtx.clearRect(0, 0, clientCanvas.width, clientCanvas.height);
        document.getElementById('client_signature').value = '';
    }

    // Technician signature handling
    var techCanvas = document.getElementById('technician_signature_canvas');
    var techCtx = techCanvas.getContext('2d');
    var techIsDrawing = false;
    var techLastX = 0;
    var techLastY = 0;

    techCanvas.addEventListener('mousedown', function(e) {
        techIsDrawing = true;
        [techLastX, techLastY] = [e.offsetX, e.offsetY];
    });

    techCanvas.addEventListener('mousemove', function(e) {
        if (techIsDrawing) {
            techDrawLine(techLastX, techLastY, e.offsetX, e.offsetY);
            [techLastX, techLastY] = [e.offsetX, e.offsetY];
        }
    });

    techCanvas.addEventListener('mouseup', function() {
        techIsDrawing = false;
        saveTechSignature();
    });

    techCanvas.addEventListener('mouseleave', function() {
        techIsDrawing = false;
    });

    function techDrawLine(x1, y1, x2, y2) {
        techCtx.beginPath();
        techCtx.moveTo(x1, y1);
        techCtx.lineTo(x2, y2);
        techCtx.strokeStyle = '#000';
        techCtx.lineWidth = 2;
        techCtx.stroke();
        techCtx.closePath();
    }

    function saveTechSignature() {
        var techSignatureData = techCanvas.toDataURL();
        document.getElementById('technician_signature').value = techSignatureData;
    }

    function clearTechSignature() {
        techCtx.clearRect(0, 0, techCanvas.width, techCanvas.height);
        document.getElementById('technician_signature').value = '';
    }
</script>
</div>

<!-- Signature Fields -->

</div>

</div>
</div>

       
    
    
     
</div>

</form>
</body>
</html>
