<?php
require('db.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $company_name = $_POST['company_name'];
    $site = $_POST['site'];
    $technician_contact = $_POST['Technician_Contact'];
    $company_contact = $_POST['Company_Contact'];
    $technician_email = $_POST['Technician_email'];
    $company_email = $_POST['Company_email'];
    $netline_technician_name = $_POST['Netline_technician_name'];

    $query = "INSERT INTO client (company_name, site, technician_contact, company_contact, technician_email, company_email, netline_technician_name)
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $con->prepare($query);
    $stmt->bind_param("sssssss", $company_name, $site, $technician_contact, $company_contact, $technician_email, $company_email, $netline_technician_name);

    if ($stmt->execute()) {
        // Redirect to the next page
        header("Location: engine_information_form.php");
        exit(); // Ensure that no other code is executed after the redirection
    } else {
        echo "Error: " . $query . "<br>" . $con->error;
    }

    $stmt->close();
    $con->close();
}
?>
