  <div id="layoutSidenav_nav">
                <nav class="sb-sidenav accordion sb-sidenav-dark" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            <div class="sb-sidenav-menu-heading">Core</div>
                            <a class="nav-link" href="welcome.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>
                            
                 
                            <a class="nav-link" href="generators.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Generators
                            </a>

                            <a class="nav-link" href="Clients.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Clients
                            </a>

                            <a class="nav-link" href="maintainance.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Maintainance
                            </a>

                            <a class="nav-link" href="search.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Search
                            </a>

  <a class="nav-link" href="change-password.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-key"></i></div>
                               Change Password
                            </a>

                            <a class="nav-link" href="logout.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-sign-out-alt"></i></div>
                                Signout
                            </a>
                        </div>
                    </div>
                
                </nav>
            </div>