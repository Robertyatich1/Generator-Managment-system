<?php
// Establish database connection
$servername = "localhost";
$username = "root";
$password = "";
$database = "netline";

$conn = new mysqli($servername, $username, $password, $database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all generators from the database
$sql = "SELECT * FROM generators";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Display form to select a generator and schedule maintenance
    echo "<h2>Select Generator and Schedule Maintenance</h2>";
    echo "<form action='schedule_maintenance.php' method='post'>";
    echo "Select Generator: <select name='generator_id'>";
    while($row = $result->fetch_assoc()) {
        echo "<option value='" . $row['id'] . "'>" . $row['Manufacturer'] . " " . $row['Model'] . "</option>";
    }
    echo "</select><br>";
    echo "Maintenance Date: <input type='date' name='maintenance_date'><br>";
    echo "<input type='submit' value='Schedule Maintenance'>";
    echo "</form>";
} else {
    echo "No generators registered.";
}

// Close database connection
$conn->close();
?>


