<?php
// Check if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $generator_id = $_POST['generator_id'];
    $maintenance_date = $_POST['maintenance_date'];
    $service_comments = $_POST['service_comments'];

    // Connect to the database
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "netline";

    $conn = new mysqli($servername, $username, $password, $database);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and bind SQL statement
    $sql = "INSERT INTO maintenance_comments (generator_id, comment, date) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        die("Error in SQL query: " . mysqli_error($conn));
    }
    $stmt->bind_param("iss", $generator_id,  $service_comments, $maintenance_date);

    // Execute the prepared statement
    if ($stmt->execute()) {
        // Redirect to the home page
        header("Location: index.php"); // Replace 'index.php' with the actual URL of your home page
        exit(); // Stop script execution
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
} else {
    // If form is not submitted, redirect to the form page
    header("Location: maintenance_form.php");
    exit(); // Stop script execution
}
?>
