<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Generator Maintenance</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
        margin-top: 0;
        text-align: center;
        color: #333;
    }
    form {
        margin-bottom: 20px;
    }
    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
        color: #333;
    }
    input[type="date"],
    select,
    input[type="text"] {
        width: calc(100% - 22px);
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }
    input[type="submit"] {
        background-color: #4CAF50;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    input[type="submit"]:hover {
        background-color: #45a049;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    table, th, td {
        border: 1px solid #ccc;
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    a {
        color: blue;
        text-decoration: underline;
        cursor: pointer;
    }
    .btn {
        padding: 5px 10px;
        border: none;
        background-color: #4CAF50;
        color: white;
        text-align: center;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="container">
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "netline";

    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Handle form submission for scheduling maintenance
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generator_id']) && !empty($_POST['maintenance_date'])) {
        $generator_id = $_POST['generator_id'];
        $maintenance_date = $_POST['maintenance_date'];

        $stmt = $conn->prepare("INSERT INTO maintenance_schedule (generator_id, maintenance_date, status) VALUES (?, ?, 'Pending')");
        
        if ($stmt === false) {
            die("Error: " . $conn->error);
        }

        $stmt->bind_param("is", $generator_id, $maintenance_date);

        if ($stmt->execute()) {
            echo "Maintenance scheduled successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generator_id']) && empty($_POST['maintenance_date'])) {
        echo "Please enter a maintenance date.";
    }

    // Fetch all clients from the client table
    $sql = "SELECT * FROM client";
    $result = $conn->query($sql);

    // Check for errors
    if (!$result) {
        die("Error fetching clients: " . $conn->error);
    }

    // Display form to select a client and schedule maintenance
    if ($result->num_rows > 0) {
        echo "<h2>Select Client and Schedule Maintenance</h2>";
        echo "<form action='' method='post'>";
        echo "<label for='generator_id'>Select Client:</label>";
        echo "<select name='generator_id' id='generator_id'>";
        
        // Output options for each client
        while($row = $result->fetch_assoc()) {
            echo "<option value='" . $row['id'] . "'>" . $row['company_name'] . " - " . $row['site'] . "</option>";
        }
        
        echo "</select>";
        echo "<label for='maintenance_date'>Maintenance Date:</label>";
        echo "<input type='date' name='maintenance_date' id='maintenance_date'>";
        echo "<input type='submit' value='Schedule Maintenance'>";
        echo "</form>";

        // Display scheduled maintenance
        $sql = "SELECT ms.id, c.company_name, c.site, c.technician_contact, c.technician_email, ms.maintenance_date, DATEDIFF(ms.maintenance_date, CURDATE()) AS days_remaining, ms.status
                FROM maintenance_schedule ms
                JOIN client c ON ms.generator_id = c.id";
        $result = $conn->query($sql);

        if ($result === false) {
            die("Error fetching scheduled maintenance: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            echo "<h2>Scheduled Maintenance</h2>";
            echo "<table>";
            echo "<tr><th>Client</th><th>Site</th><th>Technician Contact</th><th>Technician Email</th><th>Maintenance Date</th><th>Days Remaining</th><th>Status</th></tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['company_name'] . "</td>";
                echo "<td>" . $row['site'] . "</td>";
                echo "<td>" . $row['technician_contact'] . "</td>";
                echo "<td>" . $row['technician_email'] . "</td>";
                echo "<td>" . $row['maintenance_date'] . "</td>";
                echo "<td>" . $row['days_remaining'] . "</td>";
                echo "<td>";
                if ($row['status'] == 'Approved') {
                    echo "<a class='btn' href='maintenance_form.php?schedule_id=" . $row['id'] . "'>Approved</a>";
                } else {
                    echo $row['status'];
                }
                echo "</td>";
                echo "</tr>";
            }
            echo "</table>";

            echo "<form action='' method='post'>";
            echo "<input type='submit' name='export_excel' value='Export to Excel'>";
            echo "</form>";
        } else {
            echo "No scheduled maintenance.";
        }
    } else {
        echo "No clients registered.";
    }

    // Handle export to Excel
    if (isset($_POST['export_excel'])) {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment; filename="maintenance_schedule.xls"');

        $sql = "SELECT c.company_name, c.site, c.technician_contact, c.technician_email, ms.maintenance_date, DATEDIFF(ms.maintenance_date, CURDATE()) AS days_remaining, ms.status
                FROM maintenance_schedule ms
                JOIN client c ON ms.generator_id = c.id";
        $result = $conn->query($sql);

        if ($result === false) {
            die("Error exporting to Excel: " . $conn->error);
        }

        if ($result->num_rows > 0) {
            echo "Client\tSite\tTechnician Contact\tTechnician Email\tMaintenance Date\tDays Remaining\tStatus\n";
            while ($row = $result->fetch_assoc()) {
                echo $row['company_name'] . "\t" . $row['site'] . "\t" . $row['technician_contact'] . "\t" . $row['technician_email'] . "\t" . $row['maintenance_date'] . "\t" . $row['days_remaining'] . "\t" . $row['status'] . "\n";
            }
        } else {
            echo "No scheduled maintenance.";
        }

        exit();
    }

    $conn->close();
    ?>
</div>

</body>
</html>
