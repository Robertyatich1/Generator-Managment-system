<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Netline Limited</title>
    <link href="css/styles.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .navbar-brand {
            display: flex;
            align-items: center;
        }
        .navbar-brand img {
            max-height: 40px; /* Adjust as needed */
            margin-right: 10px;
        }
        .navbar-brand h5 {
            margin: 0;
        }
        .card-header img {
            width: 250px;
            height: 110px;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="login.php">
                <img src="img/logo.png" alt="Logo">
                <h5>Netline Technologies Limited</h5>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="admin">Admin Panel</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Content -->
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-lg-6">
                <div class="card shadow-lg border-0 rounded-lg mt-5">
                    <div class="card-header text-center">
                        <img src="img/logo.png" alt="Logo">
                        <hr>
                        <h3 class="font-weight-light my-4">Login</h3>
                    </div>
                    <div class="card-body">
                        <?php 
                            session_start(); 
                            include_once('includes/config.php');
                            // Code for login 
                            if(isset($_POST['login'])) {
                                $password=$_POST['password'];
                                $dec_password=$password;
                                $useremail=$_POST['uemail'];
                                $ret= mysqli_query($con,"SELECT id,fname FROM users WHERE email='$useremail' and password='$dec_password'");
                                $num=mysqli_fetch_array($ret);
                                if($num>0) {
                                    $_SESSION['id']=$num['id'];
                                    $_SESSION['name']=$num['fname'];
                                    header("location:welcome.php");
                                    exit;
                                } else {
                                    echo "<script>alert('Invalid username or password');</script>";
                                }
                            }
                        ?>
                        <form method="post">
                            <div class="mb-3">
                                <label for="inputEmail" class="form-label">Email address</label>
                                <input type="email" class="form-control" id="inputEmail" name="uemail" placeholder="name@example.com" required>
                            </div>
                            <div class="mb-3">
                                <label for="inputPassword" class="form-label">Password</label>
                                <input type="password" class="form-control" id="inputPassword" name="password" placeholder="Password" required>
                            </div>
                            <div class="d-flex justify-content-between align-items-center">
                                <a href="password-recovery.php" class="small">Forgot Password?</a>
                                <button type="submit" class="btn btn-primary" name="login">Login</button>
                            </div>
                        </form>
                    </div>
                    <div class="card-footer text-center py-3">
                        <div class="small"><a href="signup.php">Need an account? Sign up!</a></div>
                        <div class="small"><a href="index.php">Back to Home</a></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include('includes/footer.php');?>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/scripts.js"></script>
</body>
</html>
