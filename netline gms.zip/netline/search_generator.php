<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Generator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        form {
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Search Generator</h2>
    <form method="GET" action="">
        <label for="search_company_name">Company Name:</label>
        <input type="text" id="search_company_name" name="search_company_name" required>
        <label for="search_generator_name">Generator Name:</label>
        <input type="text" id="search_generator_name" name="search_generator_name" required>
        <input type="submit" value="Search">
    </form>

    <?php
    require('db.php');
    if (isset($_GET['search_company_name']) && isset($_GET['search_generator_name'])) {
        $search_company_name = $_GET['search_company_name'];
        $search_generator_name = $_GET['search_generator_name'];

        $stmt = $con->prepare("SELECT * FROM generators WHERE company_name LIKE ? AND CONCAT(manufacturer, ' ', model) LIKE ?");
        $search_company_name = "%{$search_company_name}%";
        $search_generator_name = "%{$search_generator_name}%";
        $stmt->bind_param("ss", $search_company_name, $search_generator_name);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Generator Name</th><th>Company Name</th><th>Location</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                echo "<td>" . htmlspecialchars($row['manufacturer']) . " " . htmlspecialchars($row['model']) . "</td>";
                echo "<td>" . htmlspecialchars($row['company_name']) . "</td>";
                echo "<td>" . htmlspecialchars($row['location']) . "</td>";
                echo "<td><a href='maintenance_form.php?generator_id=" . htmlspecialchars($row['id']) . "'>Select</a></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "No generators found.";
        }
        $stmt->close();
    }
    ?>

    <div style="text-align: center; margin-top: 20px;">
        <a href="add_generator.php"><button>Add New Generator</button></a>
    </div>
</div>

</body>
</html>
