<?php
require('fpdf.php'); // Ensure the path to fpdf.php is correct

// Assuming you have already connected to your database and fetched necessary data
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "netline";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieving form data
$client_id = $_POST['client_id'];
$job_number = $_POST['job_number'];
$date_time = $_POST['date_time'];
$company_name = $_POST['company_name'];
$site = $_POST['site'];
$engine_model = $_POST['engine_model'];
$serial_number = $_POST['serial_number'];
$services_requested = $_POST['services_requested'];
$diagnosis = $_POST['diagnosis'];

// Initialize FPDF
$pdf = new FPDF();
$pdf->AddPage();

// Logo and header
$pdf->Image('img/logo.png', 10, 10, 50);
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(0, 10, 'Field Site Service Report', 0, 1, 'C');

// Client and job details
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(0, 10, '', 0, 1); // Empty line for spacing
$pdf->Cell(0, 10, 'Job Number: ' . $job_number, 0, 1);
$pdf->Cell(0, 10, 'Date and Time: ' . $date_time, 0, 1);
$pdf->Cell(0, 10, 'Client Name: ' . $company_name, 0, 1);
$pdf->Cell(0, 10, 'Site: ' . $site, 0, 1);
$pdf->Cell(0, 10, 'Engine Model: ' . $engine_model, 0, 1);
$pdf->Cell(0, 10, 'Serial Number: ' . $serial_number, 0, 1);
$pdf->Cell(0, 10, 'Services Requested: ' . $services_requested, 0, 1);
$pdf->Cell(0, 10, 'Diagnosis: ' . $diagnosis, 0, 1);

// Task table
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, '', 0, 1); // Empty line for spacing
$pdf->Cell(0, 10, 'Task Table', 0, 1);
$pdf->SetFont('Arial', '', 12);

$pdf->SetFillColor(200, 200, 200);
$pdf->Cell(65, 10, 'Task', 1, 0, 'C', true);
$pdf->Cell(65, 10, 'Done?', 1, 0, 'C', true);
$pdf->Cell(65, 10, 'Task', 1, 0, 'C', true);
$pdf->Cell(65, 10, 'Done?', 1, 1, 'C', true);

// Example data, replace with your dynamic data
$tasks = [
    ['Clean Machine', 'Yes', 'Clean Fluid Level', 'Yes'],
    ['Check Electrical', 'Yes', 'Check Hoses', 'Yes'],
    ['Leakages & Loose connections', 'Yes', 'Controller History', 'Yes'],
    ['Radiator cap', 'Yes', 'Fuel Leakage', 'Yes'],
    ['Radiator Leakage', 'Yes', 'Fuel cap', 'Yes']
];

foreach ($tasks as $task) {
    $pdf->Cell(65, 10, $task[0], 1);
    $pdf->Cell(65, 10, $task[1], 1);
    $pdf->Cell(65, 10, $task[2], 1);
    $pdf->Cell(65, 10, $task[3], 1, 1);
}

// Parts table
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, '', 0, 1); // Empty line for spacing
$pdf->Cell(0, 10, 'Parts Table', 0, 1);
$pdf->SetFont('Arial', '', 12);

$pdf->SetFillColor(200, 200, 200);
$pdf->Cell(65, 10, 'Parts Name', 1, 0, 'C', true);
$pdf->Cell(65, 10, 'Quantity', 1, 0, 'C', true);
$pdf->Cell(65, 10, 'Part Number', 1, 1, 'C', true);

// Example data, replace with your dynamic data
$parts = [
    ['Oil Filters', '2', 'ABC123'],
    ['Fuel Filters', '1', 'DEF456'],
    ['Air Filters', '3', 'GHI789'],
    ['Water Filters', '1', 'JKL012'],
    ['Spark Plugs', '4', 'MNO345'],
    ['Battery', '1', 'PQR678']
];

foreach ($parts as $part) {
    $pdf->Cell(65, 10, $part[0], 1);
    $pdf->Cell(65, 10, $part[1], 1);
    $pdf->Cell(65, 10, $part[2], 1, 1);
}

// Job Completion Report
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 10, '', 0, 1); // Empty line for spacing
$pdf->Cell(0, 10, 'Job Completion Report', 0, 1);
$pdf->SetFont('Arial', '', 12);

$job_successful = isset($_POST['job_successful']) ? ($_POST['job_successful'] == 'yes' ? 'Yes' : 'No') : '';
$environment_clean = isset($_POST['environment_clean']) ? ($_POST['environment_clean'] == 'yes' ? 'Yes' : 'No') : '';
$responsibility_parts = isset($_POST['responsibility_parts']) ? ($_POST['responsibility_parts'] == 'customer' ? 'Customer' : 'Netline') : '';

$pdf->Cell(0, 10, 'Was the job successful? ' . $job_successful, 0, 1);
$pdf->Cell(0, 10, 'Have you left the environment clean? ' . $environment_clean, 0, 1);
$pdf->Cell(0, 10, 'Responsibility for used parts and oil disposal: ' . $responsibility_parts, 0, 1);

// Signatures (not shown in PDF generation)

// Output PDF
$pdf->Output('D', 'FieldSiteServiceReport.pdf'); // 'D' for download, change as needed
?>
