<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Panel - Generated Reports</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        td a {
            text-decoration: none;
            color: #007bff;
        }
    </style>
</head>
<body>
    <h2>Generated Reports</h2>
    <table>
        <thead>
            <tr>
                <th>File Name</th>
                <th>Date Generated</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Create 'reports' directory if it doesn't exist
            $directory = 'reports/';
            if (!is_dir($directory)) {
                mkdir($directory, 0755, true); // Create directory with permission 0755
            }

            // Open a directory, and read its contents
            if (is_dir($directory)) {
                if ($handle = opendir($directory)) {
                    // Loop through directory files
                    while (($file = readdir($handle)) !== false) {
                        // Check if file is a PDF
                        if (pathinfo($file, PATHINFO_EXTENSION) == 'pdf') {
                            // Get file creation date
                            $date_generated = date('Y-m-d H:i:s', filectime($directory . $file));

                            // Output table row with file details and download link
                            echo '<tr>';
                            echo '<td>' . $file . '</td>';
                            echo '<td>' . $date_generated . '</td>';
                            echo '<td><a href="' . $directory . $file . '" target="_blank">Download</a></td>';
                            echo '</tr>';
                        }
                    }
                    closedir($handle);
                }
            }
            ?>
        </tbody>
    </table>
</body>
</html>
