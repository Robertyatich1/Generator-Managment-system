<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Approval - Generator Maintenance</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        max-width: 800px;
        margin: 0 auto;
        padding: 20px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }
    h2 {
        margin-top: 0;
        text-align: center;
        color: #333;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    table, th, td {
        border: 1px solid #ccc;
    }
    th, td {
        padding: 10px;
        text-align: left;
    }
    th {
        background-color: #f2f2f2;
    }
    .btn {
        padding: 5px 10px;
        border: none;
        background-color: #4CAF50;
        color: white;
        text-align: center;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn:hover {
        background-color: #45a049;
    }
</style>
</head>
<body>

<div class="container">
    <h2>Pending Maintenance Approvals</h2>
    <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "netline";

    // Connect to the database
    $conn = new mysqli($servername, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Handle approval submission
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['approve_id'])) {
        $approve_id = $_POST['approve_id'];

        $stmt = $conn->prepare("UPDATE maintenance_schedule SET status = 'Approved' WHERE id = ?");
        
        if ($stmt === false) {
            die("Error: " . $conn->error);
        }

        $stmt->bind_param("i", $approve_id);

        if ($stmt->execute()) {
            echo "Maintenance request approved successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }

    // Fetch all pending maintenance requests
    $sql = "SELECT ms.id, c.company_name, c.site, c.technician_contact, c.technician_email, ms.maintenance_date, DATEDIFF(ms.maintenance_date, CURDATE()) AS days_remaining, ms.status
            FROM maintenance_schedule ms
            JOIN client c ON ms.generator_id = c.id
            WHERE ms.status = 'Pending'";
    $result = $conn->query($sql);

    if ($result === false) {
        die("Error fetching pending maintenance requests: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        echo "<table>";
        echo "<tr><th>Client</th><th>Site</th><th>Technician Contact</th><th>Technician Email</th><th>Maintenance Date</th><th>Days Remaining</th><th>Action</th></tr>";
        while($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>" . $row['company_name'] . "</td>";
            echo "<td>" . $row['site'] . "</td>";
            echo "<td>" . $row['technician_contact'] . "</td>";
            echo "<td>" . $row['technician_email'] . "</td>";
            echo "<td>" . $row['maintenance_date'] . "</td>";
            echo "<td>" . $row['days_remaining'] . "</td>";
            echo "<td>";
            echo "<form action='' method='post' style='display:inline;'>";
            echo "<input type='hidden' name='approve_id' value='" . $row['id'] . "'>";
            echo "<input type='submit' value='Approve' class='btn'>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "No pending maintenance requests.";
    }

    $conn->close();
    ?>
</div>

</body>
</html>
