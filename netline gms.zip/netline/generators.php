<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Generator</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #eaf2f8; /* Light blue shade */
            margin: 0;
            padding: 0;
        }
        .container {
            width: 60%; /* Adjust container width */
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff; /* White background */
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            position: relative; /* Added for positioning the back button */
        }
        .form-group {
            width: 100%;
            margin-bottom: 20px;
            box-sizing: border-box;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            color: #333;
        }
        .form-group input[type="text"],
        .form-group input[type="date"],
        .form-group input[type="number"],
        .form-group select {
            width: 100%; /* Make input fields full width */
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-top: 5px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            float: right;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        .back-button {
            background-color: #f44336; /* Red color */
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        .back-button:hover {
            background-color: #d32f2f;
        }
        .clearfix::after {
            content: "";
            clear: both;
            display: table;
        }
        h2 {
            text-align: center;
            color: #333;
        }
    </style>
</head>
<body>
    <div class="container">
        <button type="button" class="back-button" onclick="history.back();">Back</button>
        <form action="submit_generator.php" method="POST" class="clearfix">
            <h2>Client Location Information</h2>
            <div class="form-group">
                <label for="company_name">Company Name:</label>
                <input type="text" id="company_name" name="company_name" required>
            </div>
            <div class="form-group">
                <label for="address">Site:</label>
                <input type="text" id="site" name="site" required>
            </div>
            <div class="form-group">
                <label for="Technician_Contact">Technician Contact:</label>
                <input type="text" id="Technician_Contact" name="Technician_Contact" required>
            </div>
            <div class="form-group">
                <label for="Company_Contact">Company Contact:</label>
                <input type="text" id="Company_Contact" name="Company_Contact">
            </div>
            <div class="form-group">
                <label for="Technician_email">Technician email:</label>
                <input type="text" id="Technician_email" name="Technician_email" required>
            </div>
            <div class="form-group">
                <label for="Company_email">Company Email:</label>
                <input type="text" id="Company_email" name="Company_email" required>
            </div>
            <div class="form-group">
                <label for="Netline_technician_name">Netline Technician Name:</label>
                <select id="Netline_technician_name" name="Netline_technician_name" required>
                <?php
                    require('db.php');
                    $result = $con->query("SELECT fname, lname FROM users");

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $full_name = $row['fname'] . " " . $row['lname'];
                            echo "<option value='" . $full_name . "'>" . $full_name . "</option>";
                        }
                    } else {
                        echo "<option value=''>No users found</option>";
                    }
                ?>
                </select>
            </div>
            <div class="form-group" style="text-align: center;">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>
</html>
