<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generator Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eaf2f8;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Generator Details</h2>

        <?php
        if (isset($_GET['id'])) {
            $generator_id = $_GET['id'];

            // Connect to the database
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "netline";

            $conn = new mysqli($servername, $username, $password, $database);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query for generator details
            $sql = "SELECT * FROM generators WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $generator_id);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<table>";
                echo "<tr><th>ID</th><td>" . htmlspecialchars($row['id']) . "</td></tr>";
                echo "<tr><th>Manufacturer</th><td>" . htmlspecialchars($row['manufacturer']) . "</td></tr>";
                echo "<tr><th>Model</th><td>" . htmlspecialchars($row['model']) . "</td></tr>";
                echo "<tr><th>Installation Date</th><td>" . htmlspecialchars($row['installation_date']) . "</td></tr>";
                echo "<tr><th>Capacity</th><td>" . htmlspecialchars($row['capacity']) . "</td></tr>";
                echo "<tr><th>Location</th><td>" . htmlspecialchars($row['location']) . "</td></tr>";
                echo "<tr><th>Status</th><td>" . htmlspecialchars($row['status']) . "</td></tr>";
                echo "<tr><th>Company Name</th><td>" . htmlspecialchars($row['company_name']) . "</td></tr>";
                echo "<tr><th>Address</th><td>" . htmlspecialchars($row['address']) . "</td></tr>";
                echo "<tr><th>Contact</th><td>" . htmlspecialchars($row['contact']) . "</td></tr>";
                echo "<tr><th>Email</th><td>" . htmlspecialchars($row['email']) . "</td></tr>";
                echo "</table>";

                // Query for scheduled maintenance dates
                $sql_maintenance = "SELECT * FROM maintenance_comments WHERE generator_id = ?";
                $stmt_maintenance = $conn->prepare($sql_maintenance);
                if ($stmt_maintenance) {
                    $stmt_maintenance->bind_param("i", $generator_id);
                    $stmt_maintenance->execute();
                    $result_maintenance = $stmt_maintenance->get_result();

                    if ($result_maintenance->num_rows > 0) {
                        echo "<h3>Scheduled Maintenance Dates</h3>";
                        echo "<table>";
                        echo "<tr><th>Comment</th><th>Date</th></tr>";
                        while ($maintenance_row = $result_maintenance->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . (isset($maintenance_row['comment']) ? htmlspecialchars($maintenance_row['comment']) : "") . "</td>";
                            echo "<td>" . (isset($maintenance_row['date']) ? htmlspecialchars($maintenance_row['date']) : "") . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p>No scheduled maintenance dates found.</p>";
                    }
                } else {
                    echo "<p>Error preparing maintenance schedule query.</p>";
                }

                // Query for engine information
                $sql_engine = "SELECT * FROM EngineInformation WHERE GeneratorID = ?";
                $stmt_engine = $conn->prepare($sql_engine);
                if ($stmt_engine) {
                    $stmt_engine->bind_param
                    ("i", $generator_id);
                    $stmt_engine->execute();
                    $result_engine = $stmt_engine->get_result();

                    if ($result_engine->num_rows > 0) {
                        echo "<h3>Engine Information</h3>";
                        echo "<table>";
                        echo "<tr><th>Serial Number</th><th>Size (kW)</th><th>Fuel Type</th><th>Rotation Type</th><th>Design</th><th>Starting System</th><th>Oil Filter Number</th><th>Fuel Filter Number</th><th>Air Filter Number</th><th>Fan Belt Number</th><th>Heater Number</th><th>Last Oil Change</th><th>Oil Capacity</th><th>Coolant Capacity</th><th>Fuel Tank Capacity</th><th>Fuel Consumption</th></tr>";
                        while ($engine_row = $result_engine->fetch_assoc()) {
                            echo "<tr>";
                            echo "<td>" . (isset($engine_row['SerialNumber']) ? htmlspecialchars($engine_row['SerialNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['SizeKw']) ? htmlspecialchars($engine_row['SizeKw']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['FuelType']) ? htmlspecialchars($engine_row['FuelType']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['RotationType']) ? htmlspecialchars($engine_row['RotationType']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['Design']) ? htmlspecialchars($engine_row['Design']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['StartingSystem']) ? htmlspecialchars($engine_row['StartingSystem']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['OilFilterNumber']) ? htmlspecialchars($engine_row['OilFilterNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['FuelFilterNumber']) ? htmlspecialchars($engine_row['FuelFilterNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['AirFilterNumber']) ? htmlspecialchars($engine_row['AirFilterNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['FanBeltNumber']) ? htmlspecialchars($engine_row['FanBeltNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['HeaterNumber']) ? htmlspecialchars($engine_row['HeaterNumber']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['LastOilChange']) ? htmlspecialchars($engine_row['LastOilChange']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['OilCapacity']) ? htmlspecialchars($engine_row['OilCapacity']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['CoolantCapacity']) ? htmlspecialchars($engine_row['CoolantCapacity']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['FuelTankCapacity']) ? htmlspecialchars($engine_row['FuelTankCapacity']) : "") . "</td>";
                            echo "<td>" . (isset($engine_row['FuelConsumption']) ? htmlspecialchars($engine_row['FuelConsumption']) : "") . "</td>";
                            echo "</tr>";
                        }
                        echo "</table>";
                    } else {
                        echo "<p>No engine information found.</p>";
                    }
                } else {
                    echo "<p>Error preparing engine information query.</p>";
                }
            } else {
                echo "<p>Generator not found.</p>";
            }

            $stmt->close();
            $conn->close();
        } else {
            echo "<p>No generator ID provided.</p>";
        }
        ?>
    </div>
</body>
</html>
