<?php
require('db.php');

// Database connection details
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "netline";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and handle potential errors
    $Brand = $_POST['Brand'] ?? '';
    $SizeKw = $_POST['SizeKw'] ?? '';
    $ModelNumber = $_POST['ModelNumber'] ?? '';
    $SerialNumber = $_POST['SerialNumber'] ?? '';
    $EngineMake = $_POST['EngineMake'] ?? '';
    $EngineModelNumber = $_POST['EngineModelNumber'] ?? '';
    $EngineSerialNumber = $_POST['EngineSerialNumber'] ?? '';
    $FuelType = $_POST['FuelType'] ?? '';
    $BatterySize = $_POST['BatterySize'] ?? '';
    $BatteryQuantity = $_POST['BatteryQuantity'] ?? '';
    $StartingSystem = $_POST['StartingSystem'] ?? '';
    $AirFilterNumber = $_POST['AirFilterNumber'] ?? '';
    $AirFilterBrand = $_POST['AirFilterBrand'] ?? '';
    $AirFilterQuantity = $_POST['AirFilterQuantity'] ?? '';
    $FuelFilterNumber = $_POST['FuelFilterNumber'] ?? '';
    $FuelFilterBrand = $_POST['FuelFilterBrand'] ?? '';
    $FuelFilterQuantity = $_POST['FuelFilterQuantity'] ?? '';
    $OilFilterNumber = $_POST['OilFilterNumber'] ?? '';
    $OilFilterBrand = $_POST['OilFilterBrand'] ?? '';
    $OilFilterQuantity = $_POST['OilFilterQuantity'] ?? '';
    $WaterFilterNumber = $_POST['WaterFilterNumber'] ?? '';
    $WaterFilterBrand = $_POST['WaterFilterBrand'] ?? '';
    $WaterFilterQuantity = $_POST['WaterFilterQuantity'] ?? '';
    $LastOilChange = $_POST['LastOilChange'] ?? '';
    $OilCapacity = $_POST['OilCapacity'] ?? '';
    $CoolantCapacity = $_POST['CoolantCapacity'] ?? '';
    $FuelTankCapacity = $_POST['FuelTankCapacity'] ?? '';

    // Check if required fields are not empty
    if (empty($Brand) || empty($SizeKw) || empty($ModelNumber) || empty($SerialNumber) || empty($EngineMake) || empty($EngineModelNumber) || empty($EngineSerialNumber) || empty($FuelType) || empty($BatterySize) || empty($BatteryQuantity) || empty($StartingSystem) || empty($AirFilterNumber) || empty($AirFilterBrand) || empty($AirFilterQuantity) || empty($FuelFilterNumber) || empty($FuelFilterBrand) || empty($FuelFilterQuantity) || empty($OilFilterNumber) || empty($OilFilterBrand) || empty($OilFilterQuantity) || empty($WaterFilterNumber) || empty($WaterFilterBrand) || empty($WaterFilterQuantity) || empty($LastOilChange) || empty($OilCapacity) || empty($CoolantCapacity) || empty($FuelTankCapacity)) {
        echo "<script>alert('Please fill in all required fields.');</script>";
    } else {
        // Prepare SQL statement to insert data into the database
        $sql = "INSERT INTO engineinformation (Brand, SizeKw, ModelNumber, SerialNumber, EngineMake, EngineModelNumber, EngineSerialNumber, FuelType, BatterySize, BatteryQuantity, StartingSystem, AirFilterNumber, AirFilterBrand, AirFilterQuantity, FuelFilterNumber, FuelFilterBrand, FuelFilterQuantity, OilFilterNumber, OilFilterBrand, OilFilterQuantity, WaterFilterNumber, WaterFilterBrand, WaterFilterQuantity, LastOilChange, OilCapacity, CoolantCapacity, FuelTankCapacity) 
                VALUES ('$Brand', '$SizeKw', '$ModelNumber', '$SerialNumber', '$EngineMake', '$EngineModelNumber', '$EngineSerialNumber', '$FuelType', '$BatterySize', '$BatteryQuantity', '$StartingSystem', '$AirFilterNumber', '$AirFilterBrand', '$AirFilterQuantity', '$FuelFilterNumber', '$FuelFilterBrand', '$FuelFilterQuantity', '$OilFilterNumber', '$OilFilterBrand', '$OilFilterQuantity', '$WaterFilterNumber', '$WaterFilterBrand', '$WaterFilterQuantity', '$LastOilChange', '$OilCapacity', '$CoolantCapacity', '$FuelTankCapacity')";

        // Execute the SQL statement
        if ($conn->query($sql) === TRUE) {
            echo "<script>alert('Form submitted successfully!');</script>";
            echo "<script>window.location.href = 'welcome.php';</script>";
        } else {
            echo "<script>alert('Error: " . $conn->error . "');</script>";
        }
    }

    // Close the database connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Engine Information Form</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 20px;
        }
        .container {
            max-width: 800px;
            margin: auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            margin-bottom: 10px; /* Added margin between rows */
        }
        .column {
            width: calc(50% - 10px); /* Adjust as needed */
            padding: 10px;
            box-sizing: border-box;
        }
        label {
            font-weight: bold;
        }
        input[type="text"],
        input[type="date"],
        select,
        input[type="number"] {
            width: calc(100% - 16px); /* Adjusted input width to accommodate border */
            padding: 8px;
            margin: 6px 0;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            float: right;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
    </style>
    <script>
        function validateForm() {
            var inputs = document.getElementsByTagName("input");
            for (var i = 0; i < inputs.length; i++) {
                if (inputs[i].hasAttribute("required") && inputs[i].value.trim() === "") {
                    alert("Please fill in all required fields.");
                    return false;
                }
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Engine Information Form</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" onsubmit="return validateForm()">
            <div class="row">
                <div class="column">
                    <!-- Fields in the first column -->
                    <!-- Add your labels and input fields here -->
                    <label for="Brand">Brand:</label>
                    <input type="text" id="Brand" name="Brand" required>

                    <label for="SizeKw">Size in kW:</label>
                    <input type="text" id="SizeKw" name="SizeKw" required>

                    <label for="ModelNumber">Model Number:</label>
                    <input type="text" id="ModelNumber" name="ModelNumber" required>
                    
                    <label for="SerialNumber">Serial Number:</label>
                    <input type="text" id="SerialNumber" name="SerialNumber" required>

                    <label for="EngineMake">Engine Make:</label>
                    <input type="text" id="EngineMake" name="EngineMake" required>

                    <label for="EngineModelNumber">Engine Model Number:</label>
                    <input type="text" id="EngineModelNumber" name="EngineModelNumber" required>

                    <label for="EngineSerialNumber">Engine Serial Number:</label>
                    <input type="text" id="EngineSerialNumber" name="EngineSerialNumber" required>

                    <label for="FuelType">Fuel Type:</label>
                    <select id="FuelType" name="FuelType" required>
                        <option value="diesel">Diesel</option>
                        <option value="petrol">Petrol</option>
                    </select>

                    <label for="BatterySize">Battery Size:</label>
                    <input type="text" id="BatterySize" name="BatterySize" required>

                    <label for="BatteryQuantity">Number of Batteries:</label>
                    <input type="number" id="BatteryQuantity" name="BatteryQuantity" required>



                    <label for="StartingSystem">Starting System:</label>
                    <input type="text" id="StartingSystem" name="StartingSystem" required>

                    <label for="AirFilterNumber">Air Filter Number:</label>
                    <input type="text" id="AirFilterNumber" name="AirFilterNumber" required>

                    <label for="AirFilterBrand">Air Filter Brand:</label>
                    <input type="text" id="AirFilterBrand" name="AirFilterBrand" required>

                    <label for="AirFilterQuantity">Air Filter Quantity:</label>
                    <input type="number" id="AirFilterQuantity" name="AirFilterQuantity" required>
                </div>
                <div class="column">
                    <!-- Fields in the second column -->
                    <!-- Add your labels and input fields here -->
                    <label for="FuelFilterNumber">Fuel Filter Number:</label>
                    <input type="text" id="FuelFilterNumber" name="FuelFilterNumber" required>

                    <label for="FuelFilterBrand">Fuel Filter Brand:</label>
                    <input type="text" id="FuelFilterBrand" name="FuelFilterBrand" required>

                    <label for="FuelFilterQuantity">Fuel Filter Quantity:</label>
                    <input type="number" id="FuelFilterQuantity" name="FuelFilterQuantity" required>

                    <label for="OilFilterNumber">Oil Filter Number:</label>
                    <input type="text" id="OilFilterNumber" name="OilFilterNumber" required>

                    <label for="OilFilterBrand">Oil Filter Brand:</label>
                    <input type="text" id="OilFilterBrand" name="OilFilterBrand" required>

                    <label for="OilFilterQuantity">Oil Filter Quantity:</label>
                    <input type="number" id="OilFilterQuantity" name="OilFilterQuantity" required>

                    <label for="WaterFilterNumber">Water Filter Number:</label>
                    <input type="text" id="WaterFilterNumber" name="WaterFilterNumber" required>

                    <label for="WaterFilterBrand">Water Filter Brand:</label>
                    <input type="text" id="WaterFilterBrand" name="WaterFilterBrand" required>

                    <label for="WaterFilterQuantity">Water Filter Quantity:</label>
                    <input type="number" id="WaterFilterQuantity" name="WaterFilterQuantity" required>

                    <label for="LastOilChange">Last Oil Change:</label>
                    <input type="date" id="LastOilChange" name="LastOilChange" required>

                    <label for="OilCapacity">Oil Capacity:</label>
                    <input type="text" id="OilCapacity" name="OilCapacity" required>

                    <label for="CoolantCapacity">Coolant Capacity:</label>
                    <input type="text" id="CoolantCapacity" name="CoolantCapacity" required>

                    <label for="FuelTankCapacity">Fuel Tank Capacity:</label>
                    <input type="text" id="FuelTankCapacity" name="FuelTankCapacity" required>
                </div>
            </div>
            <div class="row">
                <input type="submit" value="Submit">
            </div>
        </form>
    </div>
</body>
</html>
