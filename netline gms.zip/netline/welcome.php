<?php 
session_start();
include_once('includes/config.php');
if (strlen($_SESSION['id']==0)) {
  header('location:logout.php');
} else {
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>192.168.0.12 NETLINE-GMS</title>
    <link href="https://cdn.jsdelivr.net/npm/simple-datatables@latest/dist/style.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.8.0/Chart.min.js" crossorigin="anonymous"></script>
    <style>
        .navbar, .footer {
            background-color: #4da6ff; /* Light blue */
        }
        .navbar-brand, .nav-link, .footer {
            color: white !important;
        }
        .sb-nav-fixed #layoutSidenav #layoutSidenav_nav .sb-sidenav {
            background: #4da6ff; /* Light blue */
        }
    </style>
</head>
<body class="sb-nav-fixed">
    <?php include_once('includes/navbar.php');?>
    <div id="layoutSidenav">
        <?php include_once('includes/sidebar.php');?>
        <div id="layoutSidenav_content">
            <main>
                <div class="container-fluid px-4">
                <img src="img/logo.png" alt="Logo" style="width: 250px; height: 110px;">
                    <hr />
                   
                    <!-- Pie Chart Section -->
                    <div class="row justify-content-center">
                        <div class="col-lg-8">
                            <div class="card mb-4">
                                <div class="card-header">
                                    <i class="fas fa-chart-pie me-1"></i>
                                    Generators Status
                                </div>
                                <div class="card-body">
                                    <canvas id="generatorPieChart" style="width: 100%; height: 500px;"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Pie Chart Section -->

                </div>
            </main>
            <?php include('includes/footer.php');?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
    <script src="js/scripts.js"></script>
    <script>
        // Retrieve data from your database to populate the pie chart
        // Example: 
        var generatorStatusData = {
            labels: ['Active', 'Inactive', 'Under Maintenance'],
            datasets: [{
                data: [30, 20, 10], // Replace with your actual data
                backgroundColor: ['#007bff', '#dc3545', '#ffc107']
            }]
        };

        // Create pie chart
        var ctx = document.getElementById('generatorPieChart').getContext('2d');
        var myPieChart = new Chart(ctx, {
            type: 'pie',
            data: generatorStatusData,
            options: {
                maintainAspectRatio: false
            }
        });
    </script>
</body>
</html>
<?php } ?>
