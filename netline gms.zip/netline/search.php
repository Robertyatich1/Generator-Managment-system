<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Generator</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eaf2f8;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 80%;
            margin: auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
        }
        .form-group {
            width: 100%;
            margin-bottom: 20px;
            box-sizing: border-box;
        }
        .form-group label {
            display: block;
            font-weight: bold;
            color: #333;
        }
        .form-group input[type="text"] {
            width: calc(100% - 22px);
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
            margin-top: 5px;
        }
        .form-group input[type="radio"] {
            margin-right: 10px;
        }
        input[type="submit"] {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Search Generator</h2>
        <form action="" method="GET">
            <div class="form-group">
                <label for="search_query">Search:</label>
                <input type="text" id="search_query" name="search_query" required>
            </div>
            <div class="form-group">
                <label for="search_by">Search by:</label>
                <input type="radio" id="search_by_name" name="search_by" value="name" checked>
                <label for="search_by_name">Generator Name</label>
                <input type="radio" id="search_by_company" name="search_by" value="company">
                <label for="search_by_company">Company Name</label>
            </div>
            <div class="form-group">
                <input type="submit" value="Search">
            </div>
        </form>

        <?php
        if (isset($_GET['search_query']) && isset($_GET['search_by'])) {
            $search_query = $_GET['search_query'];
            $search_by = $_GET['search_by'];

            // Connect to the database
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "netline";

            $conn = new mysqli($servername, $username, $password, $database);
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Search query
            if ($search_by == "name") {
                $sql = "SELECT id, manufacturer, model, installation_date, capacity, location, status, company_name, address, contact FROM generators WHERE CONCAT(manufacturer, ' ', model) LIKE ?";
            } else if ($search_by == "company") {
                $sql = "SELECT id, manufacturer, model, installation_date, capacity, location, status, company_name, address, contact FROM generators WHERE company_name LIKE ?";
            }

            $stmt = $conn->prepare($sql);
            $search_query = "%$search_query%";
            $stmt->bind_param("s", $search_query);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                echo "<table>";
                echo "<tr><th>ID</th><th>Generator Name</th><th>Manufacturer</th><th>Model</th><th>Installation Date</th><th>Capacity</th><th>Location</th><th>Status</th><th>Company Name</th><th>Address</th><th>Contact</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['id']) . "</td>";
                    echo "<td><a href='generator_details.php?id=" . htmlspecialchars($row['id']) . "'>" . htmlspecialchars($row['manufacturer']) . " " . htmlspecialchars($row['model']) . "</a></td>";
                    echo "<td>" . htmlspecialchars($row['manufacturer']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['model']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['installation_date']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['capacity']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['location']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['company_name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['address']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['contact']) . "</td>";
                   // echo "<td>" . htmlspecialchars($row['email']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No generators found.";
            }

            $stmt->close();
            $conn->close();
        }
        ?>
    </div>
</body>
</html>
